import { Component } from '@angular/core';

@Component({
  selector: 'siva',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'siva'; 
}
